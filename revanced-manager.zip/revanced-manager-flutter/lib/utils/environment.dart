// Dummy environment variables used for building the app locally. These automatically get set with correct values during workflow builds.
class Environment {
  static const sentryDSN = '';
  static const crowdinKEY = '';
}