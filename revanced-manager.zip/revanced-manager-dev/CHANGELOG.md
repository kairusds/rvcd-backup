# [0.1.0-dev.1](https://github.com/revanced/revanced-manager/compare/v0.0.57...v0.1.0-dev.1) (2023-03-23)


### Features

* **ci:** update crowdin workflow to use new main branch ([ded59d2](https://github.com/revanced/revanced-manager/commit/ded59d2da0d193b2dea4a5a7f2fc8eefaceecc0a))
* remove notice about stale development [skip ci] ([62f7a82](https://github.com/revanced/revanced-manager/commit/62f7a820d8ee2506376306e119698d427de745ef))
