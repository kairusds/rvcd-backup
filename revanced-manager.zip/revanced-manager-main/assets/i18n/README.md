# Nuke:tm:

> ![CAUTION]
> Some of the code are licensed under BSD 3-Clause License, please check inside the code file for more information.

## Usage

Move to your desire directory and run

```bash
dart nuke.dart
```

and it will remove all the empty keys from the JSON files in the current folder.
