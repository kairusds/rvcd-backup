# 🔄 Updating ReVanced Manager

In order to keep up with the latest features and bug fixes, it is recommended to keep ReVanced Manager up to date.

## ✅ Updating steps

1. Navigate to the **Dashboard** tab from the bottom navigation bar
2. Tap on the **Update** button in the **Updates** section

## ⏭️ What's next

The next page will bring you back to the usage page.

Continue: [🛠️ Usage](2_usage.md)
