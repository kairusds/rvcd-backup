# 💼 Prerequisites

To use ReVanced Manager, you need to fulfill certain requirements.

## 🤝 Requirements

- An Android device running Android 8 or higher

## ⏭️ What's next

The next page will explain how to install ReVanced Manager.

Continue: [⬇️ Installation](1_installation.md)
