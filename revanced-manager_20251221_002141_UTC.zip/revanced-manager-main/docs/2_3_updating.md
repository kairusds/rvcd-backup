# 🔄 Updating ReVanced Manager

Learn how to update ReVanced Manager.

## ✅ Updating steps

1. Navigate to the **Dashboard** tab from the bottom navigation bar
2. Tap on the **Update** button in the **Updates** section

## ⏭️ What's next

The next page will explain how to configure ReVanced Manager.

Continue: [⚙️ Configuring ReVanced Manager](2_4_settings.md)
