dependencies {
    implementation(project(":extensions:shared:library"))
    compileOnly(libs.okhttp)
}
