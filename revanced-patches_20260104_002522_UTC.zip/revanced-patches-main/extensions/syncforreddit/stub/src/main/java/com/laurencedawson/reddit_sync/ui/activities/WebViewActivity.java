package com.laurencedawson.reddit_sync.ui.activities;

import android.app.Activity;

public class WebViewActivity extends Activity {
}
