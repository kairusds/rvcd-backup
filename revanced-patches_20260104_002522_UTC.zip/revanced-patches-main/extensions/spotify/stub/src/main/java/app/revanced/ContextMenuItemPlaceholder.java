package app.revanced;

public interface ContextMenuItemPlaceholder {
    Object getViewModel();
}
