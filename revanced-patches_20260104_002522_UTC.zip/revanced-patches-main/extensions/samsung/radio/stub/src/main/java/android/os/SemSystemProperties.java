package android.os;

public class SemSystemProperties {
    public static String getSalesCode() {
        throw new UnsupportedOperationException("Stub");
    }
}