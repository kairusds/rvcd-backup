package com.amazon.avod.media.playback.state;

public interface PlayerStateType {
}