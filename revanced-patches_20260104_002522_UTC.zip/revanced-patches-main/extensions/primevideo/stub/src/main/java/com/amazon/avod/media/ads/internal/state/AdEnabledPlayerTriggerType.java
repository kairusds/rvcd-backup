package com.amazon.avod.media.ads.internal.state;

public enum AdEnabledPlayerTriggerType {
    NO_MORE_ADS_SKIP_TRANSITION
}