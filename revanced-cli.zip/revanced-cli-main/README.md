# 💻 ReVanced CLI

Command line application to use ReVanced.
