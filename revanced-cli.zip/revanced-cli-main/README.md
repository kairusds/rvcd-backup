<p align="center">
  <picture>
    <source
      width="256px"
      media="(prefers-color-scheme: dark)"
      srcset="assets/revanced-headline/revanced-headline-vertical-dark.svg"
    >
    <img 
      src="assets/revanced-headline/revanced-headline-vertical-light.svg"
    >
  </picture>
  <br>
  <a href="https://revanced.app/">
       <img height="24px" src="assets/revanced-logo/revanced-logo-round.svg" />
   </a>&nbsp;&nbsp;&nbsp;
   <a href="https://github.com/revanced">
       <picture>
           <source height="24px" media="(prefers-color-scheme: dark)" srcset="https://i.ibb.co/dMMmCrW/Git-Hub-Mark.png" />
           <img height="24px" src="https://i.ibb.co/9wV3HGF/Git-Hub-Mark-Light.png" />
       </picture>
   </a>&nbsp;&nbsp;&nbsp;
   <a href="http://revanced.app/discord">
       <img height="24px" src="https://user-images.githubusercontent.com/13122796/178032563-d4e084b7-244e-4358-af50-26bde6dd4996.png" />
   </a>&nbsp;&nbsp;&nbsp;
   <a href="https://reddit.com/r/revancedapp">
       <img height="24px" src="https://user-images.githubusercontent.com/13122796/178032351-9d9d5619-8ef7-470a-9eec-2744ece54553.png" />
   </a>&nbsp;&nbsp;&nbsp;
   <a href="https://t.me/app_revanced">
       <img height="24px" src="https://user-images.githubusercontent.com/13122796/178032213-faf25ab8-0bc3-4a94-a730-b524c96df124.png" />
   </a>&nbsp;&nbsp;&nbsp;
   <a href="https://twitter.com/revancedapp">
       <img height="24px" src="https://user-images.githubusercontent.com/13122796/178032018-6da37214-7474-4641-a1da-7af7db3a31cd.png" />
   </a>&nbsp;&nbsp;&nbsp;
   <a href="https://www.youtube.com/@ReVanced">
       <img height="24px" src="https://user-images.githubusercontent.com/13122796/178032714-c51c7492-0666-44ac-99c2-f003a695ab50.png" />
   </a>&nbsp;&nbsp;&nbsp;
   <br>
   <br>
   Continuing the legacy of Vanced
</p>


# 💻 ReVanced CLI

![GitHub Workflow Status (with event)](https://img.shields.io/github/actions/workflow/status/ReVanced/revanced-cli/release.yml)
![GPLv3 License](https://img.shields.io/badge/License-GPL%20v3-yellow.svg)

Command line application to use ReVanced.

## ❓ About

ReVanced CLI is a command line application to patch apps using ReVanced.
ReVanced CLI also comes with commands to uninstall or install patched apps and list patches from supplied patch bundles.

## 🚀 Download

You can download the most recent version of ReVanced CLI from 
[here](https://github.com/ReVanced/revanced-cli/releases/latest). Learn how to use ReVanced CLI by following the [documentation](/docs).

## 📚 Everything else

### 📙 Contributing

Thank you for considering contributing to ReVanced CLI.
You can find the contribution guidelines [here](CONTRIBUTING.md).

### 🛠️ Building

In order to build ReVanced CLI, you can follow the [documentation](/docs).

## 📜 Licence

ReVanced CLI is licensed under the GPLv3 licence. Please see the [licence file](LICENSE) for more information.
[tl;dr](https://www.tldrlegal.com/license/gnu-general-public-license-v3-gpl-3) you may copy, distribute and modify ReVanced CLI as long as you track changes/dates in source files.
Any modifications to ReVanced CLI must also be made available under the GPL along with build & install instructions.
