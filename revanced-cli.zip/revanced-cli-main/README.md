# 💻 ReVanced CLI

Command line application as an alternative to the ReVanced Manager.
