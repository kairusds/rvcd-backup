rootProject.name = "revanced-cli"
