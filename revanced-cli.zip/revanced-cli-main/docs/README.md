# 💻 Documentation and guides of ReVanced CLI

This documentation explains how to use [ReVanced CLI](https://github.com/revanced/revanced-cli).

## 📖 Table of contents

1. [💼 Prerequisites](0_prerequisites.md)
2. [🛠️ Using ReVanced CLI](1_usage.md)
