# 💻 Documentation and guides of ReVanced CLI

This documentation contains topics around [ReVanced CLI](https://github.com/revanced/revanced-cli).

## 📖 Table of contents

1. [💼 Prerequisites](0_prerequisites.md)
2. [🛠️ Using ReVanced CLI](1_usage.md)
3. [🔨 Building ReVanced CLI](2_building.md)
