package nl.nu.performance.api.client.objects;

import nl.nu.performance.api.client.interfaces.Block;

public class HeaderBlock extends Block {
    public final StyledText getTitle() {
        throw new UnsupportedOperationException("Stub");
    }
}
