package com.ss.android.ugc.aweme.follow.presenter;

import com.ss.android.ugc.aweme.feed.model.Aweme;

//Dummy class
public class FollowFeed {
    public Aweme aweme;
}
