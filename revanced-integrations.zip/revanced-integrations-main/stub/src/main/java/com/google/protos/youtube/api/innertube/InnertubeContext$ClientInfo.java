package com.google.protos.youtube.api.innertube;

public class InnertubeContext$ClientInfo {
    public int r;
}
