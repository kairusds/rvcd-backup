package com.rubenmayayo.reddit.ui.activities;

import android.app.Activity;

public class WebViewActivity extends Activity {
}
