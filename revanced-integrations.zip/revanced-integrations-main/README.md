# 🔩 ReVanced Integrations  

The official ReVanced Integrations containing classes to be merged by ReVanced Patcher.

## ❓ How to use debugging:

- Usage on Windows: ```adb logcat | findstr "revanced" > log.txt```
- Usage on Linux: ```adb logcat | grep --line-buffered "revanced" > log.txt```
  
This will write the log to a file called log.txt which you can view then.
