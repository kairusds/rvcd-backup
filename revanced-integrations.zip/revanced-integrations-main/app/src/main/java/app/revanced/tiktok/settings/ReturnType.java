package app.revanced.tiktok.settings;

public enum ReturnType {
    BOOLEAN, INTEGER, STRING, LONG, FLOAT
}
