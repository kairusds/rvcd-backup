package app.revanced.integrations.patches.components;

final class DummyFilter extends Filter { }