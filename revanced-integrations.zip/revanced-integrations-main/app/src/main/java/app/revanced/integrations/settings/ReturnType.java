package app.revanced.integrations.settings;

public enum ReturnType {

    BOOLEAN,
    INTEGER,
    STRING,
    LONG,
    FLOAT;
}
