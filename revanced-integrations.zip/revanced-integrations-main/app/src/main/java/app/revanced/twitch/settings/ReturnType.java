package app.revanced.twitch.settings;

public enum ReturnType {
    BOOLEAN, INTEGER, STRING, LONG, FLOAT
}
