package app.revanced.integrations.patches.downloads.views

class DownloadOptions {
}