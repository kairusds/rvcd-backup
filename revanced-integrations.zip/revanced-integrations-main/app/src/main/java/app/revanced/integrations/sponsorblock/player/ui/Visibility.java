package app.revanced.integrations.sponsorblock.player.ui;

public enum Visibility {
    NONE,
    PLAYER,
    BUTTON_CONTAINER,
    BOTH,
}
