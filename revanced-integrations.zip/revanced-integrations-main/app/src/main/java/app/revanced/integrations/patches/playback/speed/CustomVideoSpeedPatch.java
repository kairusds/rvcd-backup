package app.revanced.integrations.patches.playback.speed;

public class CustomVideoSpeedPatch {
    public static final float[] videoSpeeds = { 0, 0 }; // Values are useless as they are being overridden by the respective patch
}
