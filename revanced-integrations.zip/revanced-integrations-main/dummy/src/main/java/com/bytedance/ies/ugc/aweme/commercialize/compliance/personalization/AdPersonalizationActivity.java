package com.bytedance.ies.ugc.aweme.commercialize.compliance.personalization;

import android.app.Activity;

//Dummy class
public class AdPersonalizationActivity extends Activity { }
