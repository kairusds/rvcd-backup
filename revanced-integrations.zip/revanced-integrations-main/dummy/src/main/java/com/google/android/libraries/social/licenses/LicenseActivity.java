package com.google.android.libraries.social.licenses;

import android.app.Activity;

// Dummy class
public final class LicenseActivity extends Activity { }

