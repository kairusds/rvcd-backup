package com.facebook.litho;

import android.content.Context;
import android.support.v7.widget.RecyclerView;

public final class ComponentHost extends RecyclerView {
    public ComponentHost(Context context) {
        super(context);
    }
}
