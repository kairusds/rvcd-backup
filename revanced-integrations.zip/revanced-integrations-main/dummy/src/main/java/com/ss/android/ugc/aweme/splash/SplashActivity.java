package com.ss.android.ugc.aweme.splash;

import android.annotation.SuppressLint;
import android.app.Activity;

//Dummy class
@SuppressLint("CustomSplashScreen")
public class SplashActivity extends Activity {
}
