package com.ss.android.ugc.aweme.feed.model;

//Dummy class
public class Aweme {
    public boolean isAd() {
        return true;
    }
    public boolean isLive() {
        return true;
    }
    public boolean isLiveReplay() {
        return true;
    }
    public boolean isWithPromotionalMusic() {
        return true;
    }

}
