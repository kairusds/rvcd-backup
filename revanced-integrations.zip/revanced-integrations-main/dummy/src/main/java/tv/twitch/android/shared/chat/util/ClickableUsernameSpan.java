package tv.twitch.android.shared.chat.util;

import android.text.style.ClickableSpan;
import android.view.View;

public final class ClickableUsernameSpan extends ClickableSpan {
    @Override
    public void onClick(View widget) {}
}