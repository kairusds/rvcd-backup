package tv.twitch.android.feature.settings.menu;

import java.util.List;

// Dummy
public final class SettingsMenuGroup {
    public SettingsMenuGroup(List<Object> settingsMenuItems) {
        throw new UnsupportedOperationException("Stub");
    }

    public List<Object> getSettingsMenuItems() {
        throw new UnsupportedOperationException("Stub");
    }
}