package org.chromium.net;

public abstract class UrlRequest {
}
