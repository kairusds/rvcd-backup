package com.tumblr.rumblr.model;

public interface Timelineable {
    TimelineObjectType getTimelineObjectType();
}
