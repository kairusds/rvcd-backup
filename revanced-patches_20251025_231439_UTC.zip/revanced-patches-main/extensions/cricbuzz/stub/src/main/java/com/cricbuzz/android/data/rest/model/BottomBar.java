package com.cricbuzz.android.data.rest.model;

public final class BottomBar {
    public final String getName() { throw new UnsupportedOperationException(); }
}