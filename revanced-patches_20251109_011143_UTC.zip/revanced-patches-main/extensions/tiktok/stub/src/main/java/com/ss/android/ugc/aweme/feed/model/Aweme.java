package com.ss.android.ugc.aweme.feed.model;

//Dummy class
public class Aweme {
    public boolean isAd() {
        throw new UnsupportedOperationException("Stub");
    }

    public boolean isLive() {
        throw new UnsupportedOperationException("Stub");
    }

    public boolean isLiveReplay() {
        throw new UnsupportedOperationException("Stub");
    }

    public boolean isWithPromotionalMusic() {
        throw new UnsupportedOperationException("Stub");
    }

    public boolean getIsTikTokStory() {
        throw new UnsupportedOperationException("Stub");
    }

    public boolean isImage() {
        throw new UnsupportedOperationException("Stub");
    }

    public boolean isPhotoMode() {
        throw new UnsupportedOperationException("Stub");
    }

    public AwemeStatistics getStatistics() {
        throw new UnsupportedOperationException("Stub");
    }

    public String getShareUrl() {
        throw new UnsupportedOperationException("Stub");
    }
}
