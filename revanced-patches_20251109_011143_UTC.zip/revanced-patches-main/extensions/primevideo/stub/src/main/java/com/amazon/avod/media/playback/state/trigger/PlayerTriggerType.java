package com.amazon.avod.media.playback.state.trigger;

public interface PlayerTriggerType {
}