dependencies {
    compileOnly(project(":extensions:shared:library"))
}
