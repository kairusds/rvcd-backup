## 🧩 ReVanced Patches

Patches for ReVanced.
