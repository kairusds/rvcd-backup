extension {
    name = "extensions/all/screenshot/remove-screenshot-restriction.rve"
}

android {
    namespace = "app.revanced.extension"
}
