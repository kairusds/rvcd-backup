dependencies {
    implementation(project(":extensions:shared:library"))
}
