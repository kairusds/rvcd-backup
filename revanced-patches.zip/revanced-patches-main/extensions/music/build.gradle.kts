android {
    defaultConfig {
        minSdk = 26
    }
}
