dependencies {
    compileOnly(project(":extensions:tumblr:stub"))
}

android {
    defaultConfig {
        minSdk = 26
    }
}
