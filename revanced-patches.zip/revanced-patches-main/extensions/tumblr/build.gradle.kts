dependencies {
    compileOnly(project(":extensions:tumblr:stub"))
}
