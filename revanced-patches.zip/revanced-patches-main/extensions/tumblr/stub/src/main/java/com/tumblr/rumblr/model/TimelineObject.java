package com.tumblr.rumblr.model;

public class TimelineObject<T extends Timelineable> {
    public final T getData() {
        throw new UnsupportedOperationException("Stub");
    }

}
