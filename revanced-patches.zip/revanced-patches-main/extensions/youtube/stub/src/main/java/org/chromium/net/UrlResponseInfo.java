package org.chromium.net;

//dummy class
public abstract class UrlResponseInfo {

    public abstract String getUrl();

    public abstract int getHttpStatusCode();

    // Add additional existing methods, if needed.

}
