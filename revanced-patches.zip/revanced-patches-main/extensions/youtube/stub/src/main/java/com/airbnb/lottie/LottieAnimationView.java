package com.airbnb.lottie;

import java.io.InputStream;

@SuppressWarnings("unused")
public class LottieAnimationView {

    public void patch_setAnimation(InputStream stream, String cacheKey) {
        throw new RuntimeException("stub");
    }

    public final void patch_setAnimation(int rawResInt) {
        throw new RuntimeException("stub");
    }
}
