package com.google.android.libraries.youtube.rendering.ui.pivotbar;

import android.content.Context;
import android.widget.HorizontalScrollView;

public class PivotBar extends HorizontalScrollView {
    public PivotBar(Context context) {
        super(context);
    }
}
