extension {
    name = "extensions/all/connectivity/wifi/spoof/spoof-wifi.rve"
}

android {
    namespace = "app.revanced.extension"
}

dependencies {
    compileOnly(libs.annotation)
}
