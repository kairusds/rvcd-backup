extension {
    name = "extensions/all/screencapture/remove-screen-capture-restriction.rve"
}

android {
    namespace = "app.revanced.extension"
}

dependencies {
    compileOnly(libs.annotation)
}
