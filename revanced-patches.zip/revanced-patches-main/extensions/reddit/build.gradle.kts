dependencies {
    compileOnly(project(":extensions:reddit:stub"))
}
