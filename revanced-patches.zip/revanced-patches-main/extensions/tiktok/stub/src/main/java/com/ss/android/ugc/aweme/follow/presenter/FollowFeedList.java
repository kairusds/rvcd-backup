package com.ss.android.ugc.aweme.follow.presenter;

import java.util.List;

//Dummy class
public class FollowFeedList {
    public List<FollowFeed> mItems;
}
