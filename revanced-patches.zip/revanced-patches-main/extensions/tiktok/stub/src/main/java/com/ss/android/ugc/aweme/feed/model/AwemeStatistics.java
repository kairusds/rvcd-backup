package com.ss.android.ugc.aweme.feed.model;

public class AwemeStatistics {
    public long getPlayCount() {
        throw new UnsupportedOperationException("Stub");
    }
    public long getDiggCount() {
        throw new UnsupportedOperationException("Stub");
    }
}
