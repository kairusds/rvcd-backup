android.namespace = "app.revanced.extension"

dependencies {
    compileOnly(libs.annotation)
}
