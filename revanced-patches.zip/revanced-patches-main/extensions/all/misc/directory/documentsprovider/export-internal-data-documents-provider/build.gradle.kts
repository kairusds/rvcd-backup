dependencies {
    compileOnly(libs.annotation)
}
