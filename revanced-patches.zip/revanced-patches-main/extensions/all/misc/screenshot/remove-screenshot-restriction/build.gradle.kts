android.namespace = "app.revanced.extension"
