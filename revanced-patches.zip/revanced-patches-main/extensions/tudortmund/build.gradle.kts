dependencies {
    compileOnly(libs.appcompat)
}
