package nl.nu.performance.api.client.objects;

import nl.nu.performance.api.client.interfaces.Block;

public class DividerBlock extends Block  {

}
