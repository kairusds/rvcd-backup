package nl.nu.performance.api.client.objects;

import nl.nu.performance.api.client.unions.LinkFlavor;

public class Link {
    public final StyledText getTitle() {
        throw new UnsupportedOperationException("Stub");
    }

    public final LinkFlavor getLinkFlavor() {
        throw new UnsupportedOperationException("Stub");
    }
}
