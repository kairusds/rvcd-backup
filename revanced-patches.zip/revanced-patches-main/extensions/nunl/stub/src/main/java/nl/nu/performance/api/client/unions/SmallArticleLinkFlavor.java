package nl.nu.performance.api.client.unions;

public class SmallArticleLinkFlavor implements LinkFlavor {
    public final Boolean isPartner() {
        throw new UnsupportedOperationException("Stub");
    }
}
