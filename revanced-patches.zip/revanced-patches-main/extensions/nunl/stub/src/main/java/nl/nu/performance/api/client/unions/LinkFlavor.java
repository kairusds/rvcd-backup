package nl.nu.performance.api.client.unions;

public interface LinkFlavor {
}
