package nl.nu.performance.api.client.objects;

public class StyledText  {
    public final String getText() {
        throw new UnsupportedOperationException("Stub");
    }
}
