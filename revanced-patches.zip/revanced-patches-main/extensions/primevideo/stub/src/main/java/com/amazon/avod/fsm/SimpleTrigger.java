package com.amazon.avod.fsm;

public final class SimpleTrigger<T> implements Trigger<T> {
    public SimpleTrigger(T triggerType) {
    }
}