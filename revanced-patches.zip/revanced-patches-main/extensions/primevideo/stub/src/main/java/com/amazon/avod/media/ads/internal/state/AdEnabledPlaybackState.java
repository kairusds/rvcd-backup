package com.amazon.avod.media.ads.internal.state;

import com.amazon.avod.fsm.StateBase;
import com.amazon.avod.media.playback.state.PlayerStateType;
import com.amazon.avod.media.playback.state.trigger.PlayerTriggerType;

public class AdEnabledPlaybackState extends StateBase<PlayerStateType, PlayerTriggerType> {
}