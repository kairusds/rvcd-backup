package com.amazon.avod.media.ads.internal.state;

import com.amazon.avod.media.ads.AdBreak;
import com.amazon.avod.media.TimeSpan;

public class AdBreakTrigger {
    public AdBreak getBreak() {
        throw new UnsupportedOperationException();
    }

    public TimeSpan getSeekTarget() {
        throw new UnsupportedOperationException();
    }

    public TimeSpan getSeekStartPosition() {
        throw new UnsupportedOperationException();
    }
}