package com.amazon.avod.media.ads.internal.state;

public abstract class AdBreakState extends AdEnabledPlaybackState {
}