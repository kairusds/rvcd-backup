package com.amazon.avod.media;

public final class TimeSpan {
    public long getTotalMilliseconds() {
        throw new UnsupportedOperationException();
    }
}