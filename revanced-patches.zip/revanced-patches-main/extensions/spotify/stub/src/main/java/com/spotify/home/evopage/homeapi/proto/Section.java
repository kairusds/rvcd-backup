package com.spotify.home.evopage.homeapi.proto;

public final class Section {
    public static final int VIDEO_BRAND_AD_FIELD_NUMBER = 20;
    public static final int IMAGE_BRAND_AD_FIELD_NUMBER = 21;
    public int featureTypeCase_;
}
