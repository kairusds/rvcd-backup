package com.spotify.useraccount.v1;

/**
 * Used for target 8.6.98.900. Class is still present in newer app targets.
 */
public class AccountAttribute {
    public Object value_;
}
