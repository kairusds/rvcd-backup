package android.os;

import java.io.File;

public final class Environment {
    public static File getExternalStorageDirectory() {
        throw new UnsupportedOperationException("Stub");
    }
}
