package app.revanced.patches.tiktok.misc.settings.fingerprints

import app.revanced.patcher.fingerprint.method.impl.MethodFingerprint

object SettingsEntryFingerprint : MethodFingerprint(
    strings = listOf(
        "pls pass item or extends the EventUnit"
    )
)