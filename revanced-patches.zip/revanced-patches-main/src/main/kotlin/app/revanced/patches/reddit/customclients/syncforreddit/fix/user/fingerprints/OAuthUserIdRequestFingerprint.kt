package app.revanced.patches.reddit.customclients.syncforreddit.fix.user.fingerprints

internal object OAuthUserIdRequestFingerprint : BaseUserEndpointFingerprint("OAuthUserIdRequest.java")
