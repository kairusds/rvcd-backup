package app.revanced.patches.reddit.customclients.infinityforreddit.api.fingerprints

object GetHTTPBasicAuthHeaderFingerprint : AbstractClientIdFingerprint(
    "APIUtils;",
    "getHTTPBasicAuthHeader"
)