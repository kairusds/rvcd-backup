package app.revanced.patches.reddit.customclients.redditisfun.api.fingerprints

object BasicAuthorizationFingerprint : AbstractClientIdFingerprint(
    string = "fJOxVwBUyo*=f:<OoejWs:AqmIJ", // Encrypted basic authorization string.
)