package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

internal object GetLoggedInBearerTokenFingerprint : BaseClientIdFingerprint("authorization_code")