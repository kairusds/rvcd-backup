package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

internal object GetLoggedInBearerTokenFingerprint : AbstractClientIdFingerprint("authorization_code")