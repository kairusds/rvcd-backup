package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

object GetLoggedInBearerTokenFingerprint : AbstractClientIdFingerprint("authorization_code")