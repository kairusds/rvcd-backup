package app.revanced.patches.reddit.customclients.syncforreddit.fix.user.fingerprints

internal object OAuthFriendRequestFingerprint : BaseUserEndpointFingerprint("OAuthFriendRequest.java")
