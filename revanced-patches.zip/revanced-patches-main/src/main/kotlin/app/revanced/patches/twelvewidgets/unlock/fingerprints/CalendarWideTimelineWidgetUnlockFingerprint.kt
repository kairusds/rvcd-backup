package app.revanced.patches.twelvewidgets.unlock.fingerprints

object CalendarWideTimelineWidgetUnlockFingerprint :
    MethodUnlockFingerprint("CalendarWideTimelineWidgetConfigureActivity")
