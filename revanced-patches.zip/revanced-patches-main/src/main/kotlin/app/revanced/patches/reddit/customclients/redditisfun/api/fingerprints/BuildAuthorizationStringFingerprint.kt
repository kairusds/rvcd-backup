package app.revanced.patches.reddit.customclients.redditisfun.api.fingerprints

object BuildAuthorizationStringFingerprint : AbstractClientIdFingerprint(
    string = "client_id"
)