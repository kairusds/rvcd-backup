package app.revanced.patches.reddit.customclients.redditisfun.api.fingerprints

internal object BuildAuthorizationStringFingerprint : AbstractClientIdFingerprint(
    string = "client_id"
)