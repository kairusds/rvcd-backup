package app.revanced.patches.reddit.customclients.redditisfun.api.fingerprints

internal object BuildAuthorizationStringFingerprint : BaseClientIdFingerprint(
    string = "client_id"
)