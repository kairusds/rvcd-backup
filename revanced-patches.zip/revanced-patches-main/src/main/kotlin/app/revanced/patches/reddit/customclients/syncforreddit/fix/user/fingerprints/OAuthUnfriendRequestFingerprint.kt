package app.revanced.patches.reddit.customclients.syncforreddit.fix.user.fingerprints

internal object OAuthUnfriendRequestFingerprint : BaseUserEndpointFingerprint("OAuthUnfriendRequest.java")
