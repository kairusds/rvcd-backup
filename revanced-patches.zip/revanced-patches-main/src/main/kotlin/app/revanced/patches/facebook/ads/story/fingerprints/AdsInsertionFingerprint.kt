package app.revanced.patches.facebook.ads.story.fingerprints

internal object AdsInsertionFingerprint : FieldMethodFingerprint(fieldValue = "AdBucketDataSourceUtil\$attemptAdsInsertion\$1")