package app.revanced.patches.youtube.misc.microg.shared

internal object Constants {
    const val REVANCED_APP_NAME = "YouTube ReVanced"
    const val REVANCED_PACKAGE_NAME = "app.revanced.android.youtube"
    const val PACKAGE_NAME = "com.google.android.youtube"
    const val SPOOFED_PACKAGE_NAME = PACKAGE_NAME
    const val SPOOFED_PACKAGE_SIGNATURE = "24bb24c05e47e0aefa68a58a766179d9b613a600"
}