package app.revanced.patches.twitch.misc.settings

import app.revanced.patches.shared.misc.settings.BaseSettingsResourcePatch

object SettingsResourcePatch : BaseSettingsResourcePatch()