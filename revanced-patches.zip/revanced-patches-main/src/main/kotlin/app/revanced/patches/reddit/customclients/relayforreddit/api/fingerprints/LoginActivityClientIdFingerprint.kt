package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

internal object LoginActivityClientIdFingerprint : BaseClientIdFingerprint("&duration=permanent")