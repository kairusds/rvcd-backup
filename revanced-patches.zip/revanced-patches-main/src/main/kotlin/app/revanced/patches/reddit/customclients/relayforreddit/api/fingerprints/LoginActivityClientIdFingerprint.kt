package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

object LoginActivityClientIdFingerprint : AbstractClientIdFingerprint("&duration=permanent")