package app.revanced.patches.reddit.customclients.infinityforreddit.api.fingerprints

object LoginActivityOnCreateFingerprint : AbstractClientIdFingerprint(
    "LoginActivity;",
    "onCreate"
)