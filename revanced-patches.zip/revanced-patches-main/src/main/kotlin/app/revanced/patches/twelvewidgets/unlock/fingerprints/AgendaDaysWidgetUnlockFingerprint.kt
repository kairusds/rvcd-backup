package app.revanced.patches.twelvewidgets.unlock.fingerprints

object AgendaDaysWidgetUnlockFingerprint : MethodUnlockFingerprint("AgendaDaysWidgetConfigureActivity")
