package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

internal object GetRefreshTokenFingerprint : BaseClientIdFingerprint("refresh_token")