package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

internal object GetRefreshTokenFingerprint : AbstractClientIdFingerprint("refresh_token")