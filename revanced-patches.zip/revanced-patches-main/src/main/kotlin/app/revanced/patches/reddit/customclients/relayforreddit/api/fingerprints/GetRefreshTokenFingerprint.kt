package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

object GetRefreshTokenFingerprint : AbstractClientIdFingerprint("refresh_token")