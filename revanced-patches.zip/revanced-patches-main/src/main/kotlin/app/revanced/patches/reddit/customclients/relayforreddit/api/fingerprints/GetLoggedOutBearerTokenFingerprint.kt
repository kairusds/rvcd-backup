package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

internal object GetLoggedOutBearerTokenFingerprint : BaseClientIdFingerprint("https://oauth.reddit.com/grants/installed_client")