package app.revanced.patches.reddit.customclients.relayforreddit.api.fingerprints

internal object GetLoggedOutBearerTokenFingerprint : AbstractClientIdFingerprint("https://oauth.reddit.com/grants/installed_client")