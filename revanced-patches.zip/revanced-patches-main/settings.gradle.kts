rootProject.name = "revanced-patches"
