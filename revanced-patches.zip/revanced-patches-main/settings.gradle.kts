include("dummy")

rootProject.name = "revanced-patches"
