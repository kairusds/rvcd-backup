plugins {
    alias(libs.plugins.android.library) apply false
}
