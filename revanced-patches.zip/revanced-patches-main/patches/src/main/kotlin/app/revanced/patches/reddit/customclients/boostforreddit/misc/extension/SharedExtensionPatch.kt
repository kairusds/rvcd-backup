package app.revanced.patches.reddit.customclients.boostforreddit.misc.extension

import app.revanced.patches.reddit.customclients.boostforreddit.misc.extension.hooks.initHook
import app.revanced.patches.shared.misc.extension.sharedExtensionPatch

val sharedExtensionPatch = sharedExtensionPatch("boostforreddit", initHook)
