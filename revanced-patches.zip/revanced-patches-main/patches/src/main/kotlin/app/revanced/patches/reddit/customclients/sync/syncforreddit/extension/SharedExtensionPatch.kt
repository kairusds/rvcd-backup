package app.revanced.patches.reddit.customclients.sync.syncforreddit.extension

import app.revanced.patches.reddit.customclients.sync.syncforreddit.extension.hooks.initHook
import app.revanced.patches.shared.misc.extension.sharedExtensionPatch

val sharedExtensionPatch = sharedExtensionPatch("sync", initHook)
