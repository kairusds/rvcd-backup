package app.revanced.patches.reddit.misc.extension

import app.revanced.patches.shared.misc.extension.sharedExtensionPatch

val sharedExtensionPatch = sharedExtensionPatch()
