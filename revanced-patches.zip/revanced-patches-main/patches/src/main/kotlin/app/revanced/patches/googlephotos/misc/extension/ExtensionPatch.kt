package app.revanced.patches.googlephotos.misc.extension

import app.revanced.patches.shared.misc.extension.sharedExtensionPatch

val extensionPatch = sharedExtensionPatch(homeActivityInitHook)
