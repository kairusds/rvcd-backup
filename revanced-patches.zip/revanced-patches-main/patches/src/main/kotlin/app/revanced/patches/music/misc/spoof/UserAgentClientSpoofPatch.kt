package app.revanced.patches.music.misc.spoof

import app.revanced.patches.shared.misc.spoof.userAgentClientSpoofPatch

val userAgentClientSpoofPatch = userAgentClientSpoofPatch("com.google.android.apps.youtube.music")
