package app.revanced.patches.messenger.misc.extension

import app.revanced.patches.shared.misc.extension.sharedExtensionPatch

val sharedExtensionPatch = sharedExtensionPatch("messenger", messengerApplicationOnCreateHook)
