package app.revanced.patches.googlenews.misc.gms

internal object Constants {
    const val MAGAZINES_PACKAGE_NAME = "com.google.android.apps.magazines"
    const val REVANCED_MAGAZINES_PACKAGE_NAME = "app.revanced.android.magazines"
}
