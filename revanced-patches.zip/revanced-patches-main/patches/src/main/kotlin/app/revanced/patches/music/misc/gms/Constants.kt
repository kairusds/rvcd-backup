package app.revanced.patches.music.misc.gms

object Constants {
    internal const val REVANCED_MUSIC_PACKAGE_NAME = "app.revanced.android.apps.youtube.music"
    internal const val MUSIC_PACKAGE_NAME = "com.google.android.apps.youtube.music"
}
