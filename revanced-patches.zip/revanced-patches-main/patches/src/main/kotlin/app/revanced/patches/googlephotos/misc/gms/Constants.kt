package app.revanced.patches.googlephotos.misc.gms

internal object Constants {
    const val PHOTOS_PACKAGE_NAME = "com.google.android.apps.photos"
    const val REVANCED_PHOTOS_PACKAGE_NAME = "app.revanced.android.photos"
}
