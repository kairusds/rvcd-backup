package com.strava.modularframework.data;

import java.io.Serializable;

public abstract class Destination implements Serializable {
    public abstract String getUrl();
}
