package com.strava.modularframework.data;

public abstract class ModularMenuItem {
    public abstract Destination getDestination();

    public abstract String getElementName();
}
