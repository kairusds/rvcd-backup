package com.strava.modularframework.data;

public interface Module {
    String getElement();

    String getPage();
}
