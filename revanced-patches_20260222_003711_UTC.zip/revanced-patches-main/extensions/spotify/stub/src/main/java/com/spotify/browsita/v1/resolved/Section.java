package com.spotify.browsita.v1.resolved;

public final class Section {
    public static final int BRAND_ADS_FIELD_NUMBER = 6;
    public int sectionTypeCase_;
}
