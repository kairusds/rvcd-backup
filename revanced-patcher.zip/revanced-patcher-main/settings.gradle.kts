rootProject.name = "revanced-patcher"
