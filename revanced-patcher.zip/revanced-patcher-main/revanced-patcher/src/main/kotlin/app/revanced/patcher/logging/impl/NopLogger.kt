package app.revanced.patcher.logging.impl

import app.revanced.patcher.logging.Logger

@Deprecated("This will be removed in a future release")
object NopLogger : Logger