package app.revanced.patcher.fingerprint

import app.revanced.patcher.fingerprint.method.impl.MethodFingerprint

/**
 * A ReVanced fingerprint.
 * Can be a [MethodFingerprint].
 */
interface Fingerprint