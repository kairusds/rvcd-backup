# 💉 ReVanced Patcher

ReVanced Patcher used to patch Android applications.
