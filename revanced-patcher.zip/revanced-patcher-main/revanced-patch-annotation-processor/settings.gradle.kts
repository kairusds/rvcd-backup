rootProject.name = "revanced-patch-annotation-processor"

