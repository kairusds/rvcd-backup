package app.revanced.patcher.logging.impl

import app.revanced.patcher.logging.Logger

object NopLogger : Logger