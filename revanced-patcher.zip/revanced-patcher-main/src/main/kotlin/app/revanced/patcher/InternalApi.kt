package app.revanced.patcher

@RequiresOptIn(
    level = RequiresOptIn.Level.ERROR,
    message = "This is an internal API, don't rely on it.",
)
annotation class InternalApi
