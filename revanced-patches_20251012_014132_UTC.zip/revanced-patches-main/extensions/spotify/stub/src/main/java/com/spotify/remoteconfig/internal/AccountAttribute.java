package com.spotify.remoteconfig.internal;

public final class AccountAttribute {
    public Object value_;
}
