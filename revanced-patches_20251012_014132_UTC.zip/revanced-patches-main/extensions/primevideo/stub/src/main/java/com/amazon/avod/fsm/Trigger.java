package com.amazon.avod.fsm;

public interface Trigger<T> {
}