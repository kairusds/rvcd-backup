package com.amazon.avod.media.ads.internal.state;

public class ServerInsertedAdBreakState extends AdBreakState {
}