package app.revanced.patches.cricbuzz.misc.extension

import app.revanced.patches.shared.misc.extension.sharedExtensionPatch

val sharedExtensionPatch = sharedExtensionPatch("cricbuzz", applicationInitHook)
